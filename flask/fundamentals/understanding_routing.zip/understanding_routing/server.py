from flask import Flask
app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello New World!'


@app.route('/dojo')
def Dojo():
    return 'Dojo!'

@app.route('/say/<str:name>')
def Hi(name):
    return f"Hi {name}!"

@app.route('/repeat/<int:num>/<str:name>')
def repeat(num, name):
    return f"{name*num}"

if __name__ == '__main__':
    app.run(debug=True)