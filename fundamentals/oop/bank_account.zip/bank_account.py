class BankAccount:
    all_instances = []
    # don't forget to add some default values for these parameters!
    def __init__(self, int_rate, balance): 
        # your code here! (remember, instance attributes go here)
        # don't worry about user info here; we'll involve the User class soon
        self.int_rate = int_rate
        self.balance = balance
        BankAccount.all_instances.append(self)

    def deposit(self, amount):
        # your code here
        self.balance += amount
        return self

    def withdraw(self, amount):
        if (self.balance - amount) > 0:
            self.balance -= amount
        else: 
            print(f'Sorry, but you do not have enough funds to withdraw money. Your balance: {self.balance}')
        return self

    def display_account_info(self):
        print(f"Balance: ${self.balance}")
        return self

    def yield_interest(self):
        if self.balance > 0:
            self.balance += (self.balance * self.int_rate)
        else: 
            print('Your account balance is negative')
        return self

user1 = BankAccount(.05, 500)
user2 = BankAccount(.05, 550)

user1.deposit(20).deposit(20).deposit(20).withdraw(5).yield_interest().display_account_info()
user2.deposit(20).deposit(20).withdraw(10).withdraw(10).withdraw(10).withdraw(10).yield_interest().display_account_info()

