select * from names;
insert into names (name)
values('deven');
insert into names (name)
value('tyler'),('narciso'),('michael')names